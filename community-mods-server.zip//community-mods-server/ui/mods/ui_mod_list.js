var global_server_mod_list = [];
var scene_server_mod_list = {
    "new_game": [
        "coui://ui/mods/commander_merge/new_game/commander-merge.js",
        "coui://ui/mods/commander_merge/new_game/new_game.js",
        "coui://ui/mods/com.pa.quitch.qaipersonalities/new_game.js"
    ]
};
try {
    loadScript("coui://ui/mods/ui_mod_list_for_server.js");
    try { global_mod_list = _.union( global_mod_list, global_server_mod_list ) } catch (e) { console.log(e); };
    try { _.forOwn( scene_server_mod_list, function( value, key ) { if ( scene_mod_list[ key ] ) { scene_mod_list[ key ] = _.union( scene_mod_list[ key ], value ) } else { scene_mod_list[ key ] = value } } ); } catch (e) { console.log(e); }
} catch (e) { console.log(e); var global_mod_list = global_server_mod_list; var scene_mod_list = scene_server_mod_list; }
