# Commander-Merger
Acts as a universal compatibility mod between factions, allowing you to play with legion/bugs/assimilation/scenarios without any other compatibility mods

also works fine if any combination or none of the above mods are enabled.

also adds commander color picking for bugs and assimilation and works with the included legion lobby coloring




This work, https://github.com/Ferret-Master/Commander-Merger is a derivative of Legion Expansion by nicb1, Crembels, KillerKiwiJuice, mgmetal13, zx0, Alpha2546, PRoeleert, wondible, mikeyh, Quitch, Stuart98, dom314, CptConundrum, Elodea, AndreasG, Clopse, Graushwein, N30N, Qzipco, WPMarshall, xankar used under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.(https://github.com/Ferret-Master/Commander-Merger) is licenced under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License by Ferretmaster and MIT for software portions containing JavaScript code.

This project uses https://github.com/Legion-Expansion/Legion-Expansion/blob/develop/src/shared/ui/mods/com.pa.legion-expansion/new_game.js as a base for the js.

and uses https://github.com/Legion-Expansion/Legion-Expansion/blob/develop/src/shared/ui/mods/com.pa.legion-expansion/css/legion_commander_picker.css as a base for the css.

It removes the code not related to commander picking and expands the remaining code to cover both the bug faction, and assimilation.

it also adds to the css file in order to inlude the coloring of the other faction slots.
