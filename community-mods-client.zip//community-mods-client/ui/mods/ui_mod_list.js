var global_mod_list = [
    "coui://ui/mods/global_mod_list/status.js"
];
var scene_mod_list = {
    "load_planet": [
        "coui://ui/mods/system_sharing/system_sharing.js",
        "coui://ui/mods/system_sharing/load_planet.js",
        "coui://ui/mods/system_sharing/load_planet.css"
    ],
    "gw_play": [
        "coui://ui/mods/gw_play/status.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/bugfixes.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/card_tooltips.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/cards.css",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/cards.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/gwo_panel.css",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/gwo_panel.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/planets.css",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/referee.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/section_of_foreign_intelligence/section_of_foreign_intelligence.css",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/section_of_foreign_intelligence/section_of_foreign_intelligence.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_play/systems.js",
        "coui://download/community-mods-gw_play.js"
    ],
    "leaderboard": [
        "coui://ui/mods/leaderboard/status.js",
        "coui://download/community-mods-leaderboard.js"
    ],
    "live_game": [
        "coui://ui/mods/live_game/status.js",
        "coui://ui/mods/missile_command/live_game_bootstrap.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/live_game/menu.js",
        "coui://ui/mods/community-mods-client/live_game.js"
    ],
    "matchmaking": [
        "coui://ui/mods/matchmaking/status.js"
    ],
    "new_game": [
        "coui://ui/mods/new_game/status.js",
        "coui://ui/mods/community-mods-client/new_game.js"
    ],
    "new_game_ladder": [
        "coui://ui/mods/new_game_ladder/status.js"
    ],
    "replay_browser": [
        "coui://ui/mods/replay_browser/status.js",
        "coui://download/community-mods-replay_browser.js"
    ],
    "server_browser": [
        "coui://ui/mods/server_browser/status.js"
    ],
    "start": [
        "coui://ui/mods/start/status.js"
    ],
    "system_editor": [
        "coui://ui/mods/system_editor/status.js",
        "coui://download/community-mods-system_editor.js"
    ],
    "uberbar": [
        "coui://ui/mods/pa-chat/jquery.signalR-2.4.2.min.js",
        "coui://ui/mods/pa-chat/chatbox.js",
        "coui://ui/mods/pa-chat/chatbox.css"
    ],
    "gw_start": [
        "coui://ui/mods/gw_shared_systems/gw_start.css",
        "coui://ui/mods/gw_shared_systems/gw_start.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_start/gwo_start.css",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_start/setup.js",
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_start/ui.js"
    ],
    "live_game_options_bar": [
        "coui://ui/mods/missile_command/live_game_options_bar.js"
    ],
    "gw_war_over": [
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/gw_war_over/stats.js"
    ],
    "shared_build": [
        "coui://ui/mods/com.pa.quitch.gwaioverhaul/shared_build/planetary_radar.js"
    ],
    "game_over": [
        "coui://download/community-mods-game_over.js"
    ],
    "live_game_chat": [
        "coui://ui/mods/community-mods-client/live_game_chat.js"
    ]
};
