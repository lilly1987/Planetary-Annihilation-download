# Shared Systems for galactic war

Uses System Sharing and map packs to populate new Galactic Wars.

Select the system pool from Uber's systems, your systems, sharing servers, and installed map packs.

Use at your own risk - not all systems will be appropriate for the number of enemy commanders and subcommanders, and some are outright broken. That goes double for the default sharing server; the first one I tried the start planet collided instantly and the game couldn't start. If you find any such egregious systems, let me know and I'll add them to the blacklist.

Downloading from servers takes a bit. The default server has special case to sample 200 randomly from the first 2600 (the approximate total on 2016-03-17)
