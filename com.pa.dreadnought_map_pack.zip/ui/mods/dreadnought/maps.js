cShareSystems.load_pas("Dreadnought Map Pack", [
        "coui://ui/mods/dreadnought/systems/1v1_Blitz_Botchi_1.1.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Blitz_Firage_1.1.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Blitz_Heatstroke_1.3.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Acrophon_1.4.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Avalanche_1.6.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Crackle_1.1.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Crakatone_1.2.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Crest_1.2.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Foundry_1.4.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Freezer_1.2.pas",

        "coui://ui/mods/dreadnought/systems/1v1_Molg_1.3.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Nastolda_1.4.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Oasis_1.1.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Pummel_1.0.pas",

        "coui://ui/mods/dreadnought/systems/1v1_Smoker_1.4.pas",

        "coui://ui/mods/dreadnought/systems/1v1_Station_53C_2.0.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Temple-of-the-Monkey-God_2.4.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Kazranaut_2.7.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Snapper_1.2.pas",
        "coui://ui/mods/dreadnought/systems/1v1_Rustad_1.24.pas",
        "coui://ui/mods/dreadnought/systems/1v1_yukon-ho_3.2.pas",
        "coui://ui/mods/dreadnought/systems/11v11_Aquamax_1.0.pas",
        "coui://ui/mods/dreadnought/systems/16v16_Aquamax_1.0.pas",
        "coui://ui/mods/dreadnought/systems/16v16_SUPER_Aquamax_1.2.6.pas",
        "coui://ui/mods/dreadnought/systems/BabyEarth.pas"

    ]);
