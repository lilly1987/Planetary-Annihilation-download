function classicTutorial()
{
    if ( api.content.usingTitans() )
    {
        CommunityModsManager.uninstallMod( 'com.pa.mikeyh.classic-tutorial', false );
        return;
    }

    model.maybeShowTutorialPopup = function ()
    {

        if (model.doShowTutorialPopup())
        {
            model.showTutorialPopup(true);
            model.doShowTutorialPopup(false);
            model.showSinglePlayerMenu(false);
            model.showMultiplayerMenu(false);
            return true;
        }

        return false;
    }

    $( '#nav_quit' ).before( '<div id="nav-classic-tutorial" style="position:relative" class="nav_item nav_item_text btn_std_ix community-nav" data-bind="click: $root.startTutorialOrShowPopup, click_sound: \'default\', rollover_sound: \'default\'"><loc>COMMUNITY TUTORIAL</loc></div>' );
    
}

try
{
    classicTutorial();
}
catch ( e )
{
    console.error( e.message );
}