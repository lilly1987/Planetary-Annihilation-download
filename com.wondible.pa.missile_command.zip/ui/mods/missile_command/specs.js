define([], function() {
  "use strict";

  var specs = {
    base_nuke_launcher: '/pa/units/land/nuke_launcher/nuke_launcher.json'
  }
  specs.nuke_launcher = specs.base_nuke_launcher

  return specs
})
